package conecta4main;

import connect4.Connect4;
import connect4Lib.Player;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Conecta4Controller implements Initializable {

    @FXML
    private Label statusLabel;
    @FXML
    private Label scorejugador1label;
    @FXML
    private Label scorejugador2label;
    @FXML
    private GridPane tableroGrid;
    @FXML
    private Button botonSalir;
    @FXML
    private Button botonReiniciar;
    @FXML
    private Button botonRecuperarContrasena;
    @FXML
    private Button botonMostrarRanking;

    private int[][] tablero = new int[7][8];
    private boolean isPlayerOneTurn = true;

    private Player jugador1;
    private Player jugador2; // Puede ser otro jugador o la máquina

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tableroGrid.setOnMouseClicked(event -> {
            int columna = obtenerColumna(event.getX());
            if (columna < 0 || columna >= 8) {
                return; // Click fuera del tablero
            }
            if (!colocaFicha(columna, isPlayerOneTurn ? 1 : 2)) {
                statusLabel.setText("Columna llena, escoge otra columna");
                return;
            }
            int fila = obtenerFilaDisponible(columna);
            if (fila == -1) {
                return; // No se colocó la ficha
            }
            if (verificaGanador(fila, columna, isPlayerOneTurn ? 1 : 2)) {
                detectorGanador(isPlayerOneTurn ? 1 : 2);
            } else if (tableroLleno()) {
                manejarEmpate();
            } else {
                actualizaTurno();
                if (jugador2 == null) { // Asumiendo que jugador2 null indica modo un jugador
                    jugarContraMaquina();
                }
            }
        });
        botonReiniciar.setOnAction(this::actReiniciar);
        botonRecuperarContrasena.setOnAction(this::recuperarContrasena);
        botonMostrarRanking.setOnAction(this::mostrarRanking);
        reiniciaJuego();
    }

    public void setPlayers(Player jugador1, Player jugador2) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        jugador1.reiniciarPuntos(); // Inicializa puntuaciones en 0
        if (jugador2 != null) {
            jugador2.reiniciarPuntos();
        }
        scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        scorejugador2label.setText(jugador2 != null ? "Jugador Amarillo: " + jugador2.getPoints() : "Máquina");
    }

    private void activaTablero() {
        tableroGrid.setDisable(false);
    }

    private void desactivaTablero() {
        tableroGrid.setDisable(true);
    }

    private void reiniciaJuego() {
        limpiaTablero();
        activaTablero();
        isPlayerOneTurn = true;
        statusLabel.setText("Turno de: Jugador Rojo");
        statusLabel.setTextFill(Color.RED);
    }

    private void limpiaTablero() {
        for (int fila = 0; fila < 7; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                tablero[fila][columna] = 0;
                actualizaInterfaz(fila, columna, 0);
            }
        }
    }

    private void actualizaInterfaz(int fila, int columna, int jugador) {
        Node node = getNodeByRowColumnIndex(fila, columna, tableroGrid);
        if (node instanceof Circle) {
            Circle celda = (Circle) node;
            celda.setFill(jugador == 1 ? Color.RED : (jugador == 2 ? Color.YELLOW : Color.LIGHTGRAY));
        }
    }

    private boolean colocaFicha(int columna, int jugador) {
        for (int fila = 6; fila >= 0; fila--) {
            if (tablero[fila][columna] == 0) {
                tablero[fila][columna] = jugador;
                actualizaInterfaz(fila, columna, jugador);
                return true;
            }
        }
        return false;
    }

    private Node getNodeByRowColumnIndex(final int row, final int column, GridPane gridPane) {
        for (Node node : gridPane.getChildren()) {
            Integer nodeRow = GridPane.getRowIndex(node);
            Integer nodeColumn = GridPane.getColumnIndex(node);
            if ((nodeRow == null ? 0 : nodeRow) == row && (nodeColumn == null ? 0 : nodeColumn) == column) {
                return node;
            }
        }
        return null;
    }

    private boolean verificaGanador(int fila, int columna, int jugador) {
        return verificaDireccion(fila, columna, jugador, 1, 0)  // Horizontal
                || verificaDireccion(fila, columna, jugador, 0, 1)  // Vertical
                || verificaDireccion(fila, columna, jugador, 1, 1)  // Diagonal principal
                || verificaDireccion(fila, columna, jugador, 1, -1); // Diagonal inversa
    }

    private boolean verificaDireccion(int fila, int columna, int jugador, int deltaFila, int deltaColumna) {
        int cuenta = 1;
        cuenta += contarConsecutivos(fila, columna, jugador, deltaFila, deltaColumna);
        cuenta += contarConsecutivos(fila, columna, jugador, -deltaFila, -deltaColumna);
        return cuenta >= 4;
    }

    private int contarConsecutivos(int fila, int columna, int jugador, int deltaFila, int deltaColumna) {
        int cuenta = 0;
        int f = fila + deltaFila;
        int c = columna + deltaColumna;

        while (f >= 0 && f < 7 && c >= 0 && c < 8 && tablero[f][c] == jugador) {
            cuenta++;
            f += deltaFila;
            c += deltaColumna;
        }
        return cuenta;
    }

    private void actualizaTurno() {
        isPlayerOneTurn = !isPlayerOneTurn;
        statusLabel.setText("Turno de: " + (isPlayerOneTurn ? "Jugador Rojo" : "Jugador Amarillo"));
        statusLabel.setTextFill(isPlayerOneTurn ? Color.RED : Color.YELLOW);
    }

    private void manejarEmpate() {
        statusLabel.setText("¡Empate! El tablero está lleno");
        statusLabel.setTextFill(Color.ORANGE);

        int puntosJugador1 = jugador1.getPoints() / 2;
        int puntosJugador2 = jugador2 != null ? jugador2.getPoints() / 2 : 0;

        jugador1.addPoints(-puntosJugador1);
        if (jugador2 != null) {
            jugador2.addPoints(-puntosJugador2);
        }

        scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        if (jugador2 != null) {
            scorejugador2label.setText("Jugador Amarillo: " + jugador2.getPoints());
        }

        desactivaTablero();
        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> reiniciaJuego());
        pause.play();
    }

    private void detectorGanador(int ganador) {
        Connect4 connect4 = Connect4.getInstance();
        if (ganador == 1) {
            jugador1.addPoints(10);
            scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        } else if (ganador == 2 && jugador2 != null) {
            jugador2.addPoints(10);
            scorejugador2label.setText("Jugador Amarillo: " + jugador2.getPoints());
        }

        Player ganadorPlayer = (ganador == 1) ? jugador1 : jugador2;
        Player perdedorPlayer = (ganador == 1) ? jugador2 : jugador1;

        if (jugador2 == null) {
            perdedorPlayer = null;
        }

        connect4.registerRound(LocalDateTime.now(), ganadorPlayer, perdedorPlayer);

        statusLabel.setText("¡Jugador " + (ganador == 1 ? "Rojo" : "Amarillo") + " ganador!");
        desactivaTablero();

        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> reiniciaJuego());
        pause.play();
    }

    private void jugarContraMaquina() {
        PauseTransition pause = new PauseTransition(Duration.seconds(1));
        pause.setOnFinished(e -> {
            int columna;
            int intentos = 0;
            do {
                columna = (int) (Math.random() * 8);
                intentos++;
                if (intentos > 10) {
                    break;
                }
            } while (!colocaFicha(columna, 2));

            int fila = obtenerFilaDisponible(columna);
            if (fila == -1) {
                statusLabel.setText("La máquina no puede jugar en esta columna.");
                return;
            }

            if (verificaGanador(fila, columna, 2)) {
                detectorGanador(2);
            } else if (tableroLleno()) {
                manejarEmpate();
            } else {
                actualizaTurno();
            }
        });
        pause.play();
    }

    private boolean tableroLleno() {
        for (int columna = 0; columna < 8; columna++) {
            if (tablero[0][columna] == 0) {
                return false;
            }
        }
        return true;
    }

    private int obtenerColumna(double x) {
        double cellWidth = tableroGrid.getWidth() / 8;
        int columna = (int) (x / cellWidth);
        return (columna >= 0 && columna < 8) ? columna : -1;
    }

    private int obtenerFilaDisponible(int columna) {
        for (int fila = 6; fila >= 0; fila--) {
            if (tablero[fila][columna] == 0) {
                return fila;
            }
        }
        return -1;
    }

    @FXML
    private void actSalir(ActionEvent event) {
        botonSalir.getScene().getWindow().hide();
    }

    private void actCerrarSesion(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent loginRoot = fxmlLoader.load();

            Stage loginStage = new Stage();
            loginStage.setTitle("Inicio de Sesión");
            loginStage.getIcons().add(new Image(getClass().getResourceAsStream("/connect4/avatars/default.png")));
            loginStage.setScene(new Scene(loginRoot));
            loginStage.initModality(Modality.APPLICATION_MODAL);
            loginStage.show();

            Stage currentStage = (Stage) botonSalir.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            mostrarAlertas("Error", "Error al cerrar sesión.");
            e.printStackTrace();
        }
    }

    private void reiniciaPuntuaciones() {
        if (jugador1 != null) {
            scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        } else {
            System.out.println("jugador1 es null");
        }

        if (jugador2 != null) {
            scorejugador2label.setText("Jugador Amarillo: " + jugador2.getPoints());
        } else {
            System.out.println("jugador2 es null o es la máquina");
        }
    }

    private void mostrarAlertas(String title, String message) {
        Alert alert;
        switch (title.toLowerCase()) {
            case "error":
                alert = new Alert(Alert.AlertType.ERROR);
                break;
            case "éxito":
                alert = new Alert(Alert.AlertType.INFORMATION);
                break;
            default:
                alert = new Alert(Alert.AlertType.WARNING);
        }
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void actReiniciar(ActionEvent event) {
        reiniciaJuego();
    }

    @FXML
    private void recuperarContrasena(ActionEvent event) {
        TextField usuarioInput = new TextField();
        TextField correoInput = new TextField();
        Alert recuperarAlert = new Alert(Alert.AlertType.INFORMATION);
        recuperarAlert.setTitle("Recuperar contraseña");
        recuperarAlert.setHeaderText("Ingrese su usuario y correo electrónico registrado:");
        recuperarAlert.getDialogPane().setContent(new GridPane() {{
            add(new Label("Usuario:"), 0, 0);
            add(usuarioInput, 1, 0);
            add(new Label("Correo:"), 0, 1);
            add(correoInput, 1, 1);
        }});
        recuperarAlert.showAndWait();

        String usuario = usuarioInput.getText();
        String correo = correoInput.getText();
        if (usuario.isEmpty() || correo.isEmpty()) {
            mostrarAlertas("Error", "Debe ingresar ambos campos.");
            return;
        }

        String codigo = Connect4.getInstance().generarCodigoRecuperacion(usuario, correo);
        if (codigo != null) {
            mostrarAlertas("Éxito", "Se ha enviado un código a su correo: " + correo);
            TextField codigoInput = new TextField();
            Alert codigoAlert = new Alert(Alert.AlertType.CONFIRMATION);
            codigoAlert.setTitle("Ingrese el código recibido");
            codigoAlert.getDialogPane().setContent(new GridPane() {{
                add(new Label("Código:"), 0, 0);
                add(codigoInput, 1, 0);
            }});
            codigoAlert.showAndWait();

            if (codigo.equals(codigoInput.getText())) {
                String contrasena = Connect4.getInstance().obtenerContrasena(usuario);
                mostrarAlertas("Éxito", "Su contraseña es: " + contrasena);
            } else {
                mostrarAlertas("Error", "El código ingresado es incorrecto.");
            }
        } else {
            mostrarAlertas("Error", "Usuario o correo no encontrado.");
        }
    }

    @FXML
    private void mostrarRanking(ActionEvent event) {
        List<Player> ranking = Connect4.getInstance().obtenerRanking();
        ranking.sort(Comparator.comparingInt(Player::getPoints).reversed());

        StringBuilder rankingText = new StringBuilder("Ranking de jugadores:\n");
        for (int i = 0; i < ranking.size(); i++) {
            Player player = ranking.get(i);
            rankingText.append((i + 1)).append(". ").append(player.getUsername()).append(" - ").append(player.getPoints()).append(" puntos\n");
        }

        mostrarAlertas("Ranking", rankingText.toString());
    }
}

// Clase Player actualizada
package connect4Lib;

public class Player {

    private int points;
    private String username;

    public Player(String username) {
        this.username = username;
        this.points = 0;
    }

    public void addPoints(int points) {
        this.points += points;
    }

    public int getPoints() {
        return points;
    }

    public String getUsername() {
        return username;
    }

    public void reiniciarPuntos() {
        this.points = 0;
    }
}
