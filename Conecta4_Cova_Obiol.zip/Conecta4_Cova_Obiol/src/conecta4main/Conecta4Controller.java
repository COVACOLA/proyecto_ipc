package conecta4main;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class Conecta4Controller implements Initializable {

    @FXML
    private Label statusLabel;
    private Label scoreJugador1Label;
    private Label scoreJugador2Label;

    private int scoreJugador1 = 0;
    private int scoreJugador2 = 0;

    @FXML
    private GridPane tableroGrid;
    private int[][] tablero = new int[7][8];
    private boolean isPlayerOneTurn = true;
    @FXML
    private Label scorejugador1label;
    @FXML
    private Label scorejugador2label;
    @FXML
    private Button botonSalir;

    private void activaTablero() {
        tableroGrid.setDisable(false);
    }

    private void desactivaTablero() {
        tableroGrid.setDisable(true);
    }

    private void reiniciaJuego() {
        limpiaTablero();
        activaTablero();
        isPlayerOneTurn = true;
        statusLabel.setText("Jugador Rojo");
        statusLabel.setTextFill(Color.RED);
    }

    private void limpiaTablero() {
        for (int fila = 0; fila < 7; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                tablero[fila][columna] = 0;
                actualizaInterfaz(fila, columna, 0);
            }
        }
    }

    private void actualizaInterfaz(int fila, int columna, int jugador) {
        Node node = getNodeByRowColumnIndex(fila, columna, tableroGrid);
        if (node instanceof Circle) {
            Circle celda = (Circle) node;
            celda.setFill(jugador == 1 ? Color.RED : (jugador == 2 ? Color.YELLOW : Color.LIGHTGRAY));
        }
    }

    private boolean colocaFicha(int columna, int jugador) {
        for (int fila = 6; fila >= 0; fila--) {
            if (tablero[fila][columna] == 0) {
                tablero[fila][columna] = jugador;
                actualizaInterfaz(fila, columna, jugador);
                return true;
            }
        }
        return false;
    }

    private Node getNodeByRowColumnIndex(final int row, final int column, GridPane gridPane) {
        for (Node node : gridPane.getChildren()) {
            Integer nodeRow = GridPane.getRowIndex(node);
            Integer nodeColumn = GridPane.getColumnIndex(node);
            if (nodeRow != null && nodeRow == row && nodeColumn != null && nodeColumn == column) {
                return node;
            }
        }
        return null;
    }

    private boolean verificaGanador(int fila, int columna, int jugador) {
        return verificaDireccion(fila, columna, jugador, 1, 0)  // Horizontal
                || verificaDireccion(fila, columna, jugador, 0, 1)  // Vertical
                || verificaDireccion(fila, columna, jugador, 1, 1)  // Diagonal principal
                || verificaDireccion(fila, columna, jugador, 1, -1); // Diagonal inversa
    }

    private boolean verificaDireccion(int fila, int columna, int jugador, int deltaFila, int deltaColumna) {
        int cuenta = 1;
        cuenta += contarConsecutivos(fila, columna, jugador, deltaFila, deltaColumna);
        cuenta += contarConsecutivos(fila, columna, jugador, -deltaFila, -deltaColumna);
        return cuenta >= 4;
    }

    private int contarConsecutivos(int fila, int columna, int jugador, int deltaFila, int deltaColumna) {
        int cuenta = 0;
        int f = fila + deltaFila;
        int c = columna + deltaColumna;

        while (f >= 0 && f < 7 && c >= 0 && c < 8 && tablero[f][c] == jugador) {
            cuenta++;
            f += deltaFila;
            c += deltaColumna;
        }
        return cuenta;
    }

    private void actualizaTurno() {
        isPlayerOneTurn = !isPlayerOneTurn;
        statusLabel.setText("Turno de: " + (isPlayerOneTurn ? "Jugador Rojo" : "Jugador Amarillo"));
        statusLabel.setTextFill(isPlayerOneTurn ? Color.RED : Color.YELLOW);
    }

    private void modificaScore(int ganador) {
        if (ganador == 1) {
            scoreJugador1++;
            scoreJugador1Label.setText("Jugador Rojo: " + scoreJugador1);
        } else if (ganador == 2) {
            scoreJugador2++;
            scoreJugador2Label.setText("Jugador Amarillo: " + scoreJugador2);
        }
    }

    private void detectorGanador(int ganador) {
        modificaScore(ganador);
        statusLabel.setText("¡Jugador " + (ganador == 1 ? "Rojo" : "Amarillo") + " ganador!");
        desactivaTablero();

        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> reiniciaJuego());
        pause.play();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tableroGrid.setOnMouseClicked(event -> {
            int columna = obtenerColumna(event.getX());
            if (!colocaFicha(columna, isPlayerOneTurn ? 1 : 2)) {
                statusLabel.setText("Columna llena, escoge otra columna");
                return;
            }
            int fila = obtenerFilaDisponible(columna);
            if (verificaGanador(fila, columna, isPlayerOneTurn ? 1 : 2)) {
                detectorGanador(isPlayerOneTurn ? 1 : 2);
            } else if (tableroLleno()) {
                statusLabel.setText("¡Empate! El tablero está lleno");
                desactivaTablero();
            } else {
                actualizaTurno();
            }
        });
        reiniciaJuego();
    }

    private boolean tableroLleno() {
        for (int columna = 0; columna < 8; columna++) {
            if (tablero[0][columna] == 0) {
                return false;
            }
        }
        return true;
    }

    private int obtenerColumna(double x) {
        return (int) (x / (tableroGrid.getWidth() / 8));
    }

    private int obtenerFilaDisponible(int columna) {
        for (int fila = 6; fila >= 0; fila--) {
            if (tablero[fila][columna] == 0) {
                return fila;
            }
        }
        return -1;
    }

    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        botonSalir.getScene().getWindow().hide();

    }

    void setParentController(InicioSesionController aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
