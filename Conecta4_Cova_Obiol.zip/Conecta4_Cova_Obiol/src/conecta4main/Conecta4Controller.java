package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Conecta4Controller implements Initializable {

    @FXML
    private Label statusLabel;
    @FXML
    private Label scorejugador1label;
    @FXML
    private Label scorejugador2label;
    @FXML
    private GridPane tableroGrid;
    @FXML
    private Button botonSalir;
    @FXML
    private Button botonReiniciar;
    @FXML
    private DatePicker fechaInicioPicker;
    @FXML
    private DatePicker fechaFinPicker;

    private int[][] tablero = new int[7][8];
    private boolean isPlayerOneTurn = true;

    // Referencias a los jugadores
    private Player jugador1;
    private Player jugador2; // Puede ser otro jugador o la máquina

    private List<Partida> partidasRealizadas = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tableroGrid.setOnMouseClicked(event -> {
            int columna = obtenerColumna(event.getX());
            if (columna < 0 || columna >= 8) {
                return; // Click fuera del tablero
            }
            if (!colocaFicha(columna, isPlayerOneTurn ? 1 : 2)) {
                statusLabel.setText("Columna llena, escoge otra columna");
                return;
            }
            int fila = obtenerFilaDisponible(columna);
            if (verificaGanador(fila, columna, isPlayerOneTurn ? 1 : 2)) {
                detectorGanador(isPlayerOneTurn ? 1 : 2);
            } else if (tableroLleno()) {
                manejarEmpate();
            } else {
                actualizaTurno();
                // Si es modo un jugador, realiza el movimiento de la máquina
                if (jugador2 == null) { // Asumiendo que jugador2 null indica modo un jugador
                    jugarContraMaquina();
                }
            }
        });
        botonReiniciar.setOnAction(this::actReiniciar); // Inicializa el botón Reiniciar
        reiniciaJuego();
    }

    public void setPlayers(Player jugador1, Player jugador2) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        reiniciarPuntos(); // Inicializa puntuaciones en 0
        scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        scorejugador2label.setText(jugador2 != null ? "Jugador Amarillo: " + jugador2.getPoints() : "Máquina");
    }

    private void reiniciarPuntos() {
        if (jugador1 != null) {
            jugador1.addPoints(-jugador1.getPoints());
        }
        if (jugador2 != null) {
            jugador2.addPoints(-jugador2.getPoints());
        }
    }

    private void activaTablero() {
        tableroGrid.setDisable(false);
    }

    private void desactivaTablero() {
        tableroGrid.setDisable(true);
    }

    private void reiniciaJuego() {
        limpiaTablero();
        activaTablero();
        isPlayerOneTurn = true;
        statusLabel.setText("Turno de: Jugador Rojo");
        statusLabel.setTextFill(Color.RED);
    }

    private void limpiaTablero() {
        for (int fila = 0; fila < 7; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                tablero[fila][columna] = 0;
                actualizaInterfaz(fila, columna, 0);
            }
        }
    }

    private void actualizaInterfaz(int fila, int columna, int jugador) {
        Node node = getNodeByRowColumnIndex(fila, columna, tableroGrid);
        if (node instanceof Circle) {
            Circle celda = (Circle) node;
            celda.setFill(jugador == 1 ? Color.RED : (jugador == 2 ? Color.YELLOW : Color.LIGHTGRAY));
        }
    }

    private boolean colocaFicha(int columna, int jugador) {
        for (int fila = 6; fila >= 0; fila--) {
            if (tablero[fila][columna] == 0) {
                tablero[fila][columna] = jugador;
                actualizaInterfaz(fila, columna, jugador);
                return true;
            }
        }
        return false;
    }

    private Node getNodeByRowColumnIndex(final int row, final int column, GridPane gridPane) {
        for (Node node : gridPane.getChildren()) {
            Integer nodeRow = GridPane.getRowIndex(node);
            Integer nodeColumn = GridPane.getColumnIndex(node);
            if ((nodeRow == null ? 0 : nodeRow) == row && (nodeColumn == null ? 0 : nodeColumn) == column) {
                return node;
            }
        }
        return null;
    }

    private boolean verificaGanador(int fila, int columna, int jugador) {
        return verificaDireccion(fila, columna, jugador, 1, 0)  // Horizontal
                || verificaDireccion(fila, columna, jugador, 0, 1)  // Vertical
                || verificaDireccion(fila, columna, jugador, 1, 1)  // Diagonal principal
                || verificaDireccion(fila, columna, jugador, 1, -1); // Diagonal inversa
    }

    private boolean verificaDireccion(int fila, int columna, int jugador, int deltaFila, int deltaColumna) {
        int cuenta = 1;
        cuenta += contarConsecutivos(fila, columna, jugador, deltaFila, deltaColumna);
        cuenta += contarConsecutivos(fila, columna, jugador, -deltaFila, -deltaColumna);
        return cuenta >= 4;
    }

    private int contarConsecutivos(int fila, int columna, int jugador, int deltaFila, int deltaColumna) {
        int cuenta = 0;
        int f = fila + deltaFila;
        int c = columna + deltaColumna;

        while (f >= 0 && f < 7 && c >= 0 && c < 8 && tablero[f][c] == jugador) {
            cuenta++;
            f += deltaFila;
            c += deltaColumna;
        }
        return cuenta;
    }

    private void actualizaTurno() {
        isPlayerOneTurn = !isPlayerOneTurn;
        statusLabel.setText("Turno de: " + (isPlayerOneTurn ? "Jugador Rojo" : "Jugador Amarillo"));
        statusLabel.setTextFill(isPlayerOneTurn ? Color.RED : Color.YELLOW);
    }

    private void manejarEmpate() {
        statusLabel.setText("¡Empate! El tablero está lleno");
        statusLabel.setTextFill(Color.ORANGE);

        desactivaTablero();
        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> reiniciaJuego());
        pause.play();
    }

    private void detectorGanador(int ganador) {
        Connect4 connect4 = Connect4.getInstance();
        if (ganador == 1) {
            jugador1.addPoints(10);
            scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        } else if (ganador == 2 && jugador2 != null) {
            jugador2.addPoints(10);
            scorejugador2label.setText("Jugador Amarillo: " + jugador2.getPoints());
        }

        statusLabel.setText("¡Jugador " + (ganador == 1 ? "Rojo" : "Amarillo") + " ganador!");
        desactivaTablero();

        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> reiniciaJuego());
        pause.play();
    }

    private void jugarContraMaquina() {
        PauseTransition pause = new PauseTransition(Duration.seconds(1));
        pause.setOnFinished(e -> {
            int columna;
            int intentos = 0;
            do {
                columna = (int) (Math.random() * 8);
                intentos++;
                if (intentos > 10) {
                    break;
                }
            } while (!colocaFicha(columna, 2));

            if (tableroLleno()) {
                manejarEmpate();
            } else {
                actualizaTurno();
            }
        });
        pause.play();
    }

    private boolean tableroLleno() {
        for (int columna = 0; columna < 8; columna++) {
            if (tablero[0][columna] == 0) {
                return false;
            }
        }
        return true;
    }

    private int obtenerColumna(double x) {
        double cellWidth = tableroGrid.getWidth() / 8;
        int columna = (int) (x / cellWidth);
        return (columna >= 0 && columna < 8) ? columna : -1;
    }

    private int obtenerFilaDisponible(int columna) {
        for (int fila = 6; fila >= 0; fila--) {
            if (tablero[fila][columna] == 0) {
                return fila;
            }
        }
        return -1;
    }

    @FXML
    private void actSalir(ActionEvent event) {
        botonSalir.getScene().getWindow().hide();
    }

    private void reiniciaPuntuaciones() {
        if (jugador1 != null) {
            scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
        }
        if (jugador2 != null) {
            scorejugador2label.setText("Jugador Amarillo: " + jugador2.getPoints());
        }
    }

    private void mostrarAlertas(String title, String message) {
        Alert alert;
        switch (title.toLowerCase()) {
            case "error":
                alert = new Alert(Alert.AlertType.ERROR);
                break;
            case "éxito":
                alert = new Alert(Alert.AlertType.INFORMATION);
                break;
            default:
                alert = new Alert(Alert.AlertType.WARNING);
        }
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void actReiniciar(ActionEvent event) {
        reiniciaJuego();
    }

    public void mostrarRanking() {
        List<Player> ranking = Connect4.getInstance().getRanking();
        ranking.sort(Comparator.comparingInt(Player::getPoints).reversed());
        for (Player player : ranking) {
            System.out.println("Jugador: " + player.getNickName() + ", Puntos: " + player.getPoints());
        }
    }

    public void mostrarPartidasEnPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        List<Partida> partidasFiltradas = new ArrayList<>();
        for (Partida partida : partidasRealizadas) {
            if (!partida.getFecha().toLocalDate().isBefore(fechaInicio) && !partida.getFecha().toLocalDate().isAfter(fechaFin)) {
                partidasFiltradas.add(partida);
            }
        }
        for (Partida partida : partidasFiltradas) {
            System.out.println("Fecha: " + partida.getFecha() + ", Ganador: " + partida.getGanador().getNickName() + 
                               ", Perdedor: " + (partida.getPerdedor() != null ? partida.getPerdedor().getNickName() : "N/A"));
        }
    }

    public void cambiarModoVisualizacion(boolean altoContraste) {
        if (altoContraste) {
            System.out.println("Modo de alto contraste activado.");
        } else {
            System.out.println("Modo normal activado.");
        }
    }

    private static class Partida {
        private final LocalDateTime fecha;
        private final Player ganador;
        private final Player perdedor;

        public Partida(LocalDateTime fecha, Player ganador, Player perdedor) {
            this.fecha = fecha;
            this.ganador = ganador;
            this.perdedor = perdedor;
        }

        public LocalDateTime getFecha() {
            return fecha;
        }

        public Player getGanador() {
            return ganador;
        }

        public Player getPerdedor() {
            return perdedor;
        }
    }
}
