/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conecta4main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Conecta4Main extends Application {

    private static Stage primaryStage; 

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        loadScene("Login.fxml", "Conecta4 Cova - Obiol"); 
    }

 
    public static void loadScene(String fxmlFile, String title) throws Exception {
        FXMLLoader loader = new FXMLLoader(Conecta4Main.class.getResource(fxmlFile));
        Parent root = loader.load(); 
        Scene scene = new Scene(root); 
        primaryStage.setScene(scene); 
        primaryStage.setTitle(title);
        primaryStage.show(); 
    }
    public static void main(String[] args) {
        launch(args); // Inicia la aplicación JavaFX
    }
}
