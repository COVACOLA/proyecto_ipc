/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class InicioSesionController implements Initializable {

    @FXML
    private Button botonJugar;
    @FXML
    private Button botonDosJugadores;
    @FXML
    private Button botonRanking;
    @FXML
    private Button botonSalir;
    private Player jugador1;
    private Player jugador2;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

public void setPlayers(Player jugador1, Player jugador2) {
    this.jugador1 = jugador1;
    this.jugador2 = jugador2;
    // Actualiza las etiquetas de puntuación con los puntos actuales
    //scorejugador1label.setText("Jugador Rojo: " + jugador1.getPoints());
    //scorejugador2label.setText(jugador2 != null ? "Jugador Amarillo: " + jugador2.getPoints() : "Máquina");
    System.out.println("Jugadores establecidos: " + jugador1.getNickName() + " vs " + (jugador2 != null ? jugador2.getNickName() : "Máquina"));
}    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        botonSalir.getScene().getWindow().hide();

    }

    @FXML
    private void actJugar(ActionEvent event) {
        abrirJuego("Un jugador");
    }

    @FXML
    private void actDosJugadores(ActionEvent event) {
        abrirJuego("Dos jugadores");
    }
   
    // Método para abrir la vista de juego
    private void abrirJuego(String modo) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Conecta4.fxml"));
            Parent conecta4Root = fxmlLoader.load();

            // Obtener el controlador de Conecta4
            Conecta4Controller conecta4Controller = fxmlLoader.getController();

            // Determinar el segundo jugador según el modo
            Player jugador2 = null;
            if (modo.equals("Dos jugadores")) {
                jugador2 = obtenerSegundoJugador(); // Implementa este método según tus necesidades
                if (jugador2 == null) {
                    mostrarAlertas("Error", "No se pudo obtener el segundo jugador.");
                    return;
                }
            }

            // Pasar los jugadores al controlador de juego
            conecta4Controller.setPlayers(jugador1, jugador2);

            // Crear una nueva ventana para el juego
            Stage juegoStage = new Stage();
            juegoStage.setTitle(modo);
            juegoStage.getIcons().add(new Image(getClass().getResourceAsStream("/imagenes/conecta4.png")));
            juegoStage.setScene(new Scene(conecta4Root));
            juegoStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            juegoStage.initOwner(botonJugar.getScene().getWindow()); // Establecer la ventana principal como propietaria
            juegoStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de juego
            juegoStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            mostrarAlertas("Error", "Error al abrir la ventana de Conecta4.fxml");
            e.printStackTrace();
        }
    }


    @FXML
    private void actRanking(ActionEvent event) {        
        try {
            // Cargar la vista de ranking
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Ranking.fxml")); // Asegúrate de tener este FXML
            Parent rankingRoot = fxmlLoader.load();

            // Obtener el controlador de RankingController si necesitas pasar datos
            RankingController rankingController = fxmlLoader.getController();
            // Puedes pasar datos al controlador si es necesario

            // Crear una nueva ventana para el ranking
            Stage rankingStage = new Stage();
            rankingStage.setTitle("Ranking de Jugadores");
            rankingStage.getIcons().add(new Image(getClass().getResourceAsStream("/imagenes/conecta4.png")));
            rankingStage.setScene(new Scene(rankingRoot));
            rankingStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            rankingStage.initOwner(botonRanking.getScene().getWindow()); // Establecer la ventana principal como propietaria
            rankingStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de ranking
            rankingStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            mostrarAlertas("Error", "Error al cargar la vista de Ranking.fxml");
            e.printStackTrace();
        }
    }

    
    
    // Método para habilitar/deshabilitar botones
    private void desactivarbotones(boolean disabled) {
        botonJugar.setDisable(disabled);
        botonDosJugadores.setDisable(disabled);
        botonRanking.setDisable(disabled);
        botonSalir.setDisable(disabled);
    }
    // Método para mostrar alertas
    private void mostrarAlertas(String title, String message) {
        Alert alert;
        switch (title.toLowerCase()) {
            case "error":
                alert = new Alert(Alert.AlertType.ERROR);
                break;
            case "éxito":
                alert = new Alert(Alert.AlertType.INFORMATION);
                break;
            default:
                alert = new Alert(Alert.AlertType.WARNING);
        }
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Método para obtener el segundo jugador (modo dos jugadores)
    private Player obtenerSegundoJugador() {
        // Implementa la lógica para seleccionar otro jugador.
        // Por ejemplo, podrías abrir un diálogo para que el usuario ingrese el nombre del segundo jugador.
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Seleccionar Segundo Jugador");
        dialog.setHeaderText(null);
        dialog.setContentText("Ingresa el nombre de usuario de Jugador Amarillo:");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            String nombreJugador2 = result.get().trim();
            if (nombreJugador2.isEmpty()) {
                mostrarAlertas("Error", "El nombre de usuario no puede estar vacío.");
                return null;
            }

            Connect4 connect4 = Connect4.getInstance();
            if (connect4.existsNickName(nombreJugador2)) {
                return connect4.getPlayer(nombreJugador2);
            } else {
                mostrarAlertas("Error", "El nombre de usuario del segundo jugador no existe.");
                return null;
            }
        } else {
            return null; // El usuario canceló el diálogo
        }
    }
}