/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class InicioSesionController implements Initializable {

    @FXML
    private Button botonJugar;
    @FXML
    private Button botonDosJugadores;
    @FXML
    private Button botonRanking;
    @FXML
    private Button botonSalir;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        botonSalir.getScene().getWindow().hide();

    }

    @FXML
    private void actJugar(ActionEvent event) {
        try {
            // Cargar la vista de conecta4
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Conecta4.fxml"));
            Parent conecta4Root = fxmlLoader.load();


            // Crear una nueva ventana para el menu de iniicio de sesion
            Stage menuInicioStage = new Stage();
            menuInicioStage.setTitle("Un jugador");
            menuInicioStage.getIcons().add(new Image(getClass().getResourceAsStream("/imagenes/conecta4.png")));
            menuInicioStage.setScene(new Scene(conecta4Root));
            menuInicioStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            menuInicioStage.initOwner(botonJugar.getScene().getWindow()); // Establecer la ventana principal como propietaria
            menuInicioStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de menu de inicio
        menuInicioStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            System.err.println("Error en abrir la ventana de Conecta4.fxml");
            e.printStackTrace();
        }
    }

    @FXML
    private void actDosJugadores(ActionEvent event) {
            try {
            // Cargar la vista de conecta4
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Conecta4.fxml"));
            Parent conecta4Root = fxmlLoader.load();


            // Crear una nueva ventana para el menu de iniicio de sesion
            Stage menuInicioStage = new Stage();
            menuInicioStage.setTitle("Dos jugadores");
            menuInicioStage.getIcons().add(new Image(getClass().getResourceAsStream("/imagenes/conecta4.png")));
            menuInicioStage.setScene(new Scene(conecta4Root));
            menuInicioStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            menuInicioStage.initOwner(botonJugar.getScene().getWindow()); // Establecer la ventana principal como propietaria
            menuInicioStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de menu de inicio
        menuInicioStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            System.err.println("Error en abrir la ventana de Conecta4.fxml");
            e.printStackTrace();
        }
    }

    @FXML
    private void actRanking(ActionEvent event) {
    }

    private void desactivarbotones(boolean disabled) {
        botonJugar.setDisable(disabled);
        botonDosJugadores.setDisable(disabled);
    }
    private LoginController parentController;

    // Método para establecer el controlador padre
    public void setParentController(LoginController parentController) {
        this.parentController = parentController;
    }
}
