
package conecta4main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class LoginController implements Initializable {

    @FXML
    private Button btInicio;
    @FXML
    private Button btRegistrarse;
    @FXML
    private Button btSalir;
    @FXML
    private TextField usuarioTextField;
    @FXML
    private PasswordField contraseñaTextField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     // Inicialmente, deshabilitar el botón de inicio
        btInicio.setDisable(true);

        // Añadir listeners a los campos de usuario y contraseña
        usuarioTextField.textProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
         contraseñaTextField.textProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
        }

    // Método para verificar si los campos están vacíos
    private void verificarCampos() {
        boolean camposCompletos = !usuarioTextField.getText().trim().isEmpty() && !contraseñaTextField.getText().trim().isEmpty();
        btInicio.setDisable(!camposCompletos); // Habilitar/deshabilitar el botón de inicio
    }    

    @FXML
    private void clickInicio(MouseEvent event) {
    }

    @FXML
    private void ActInicio(ActionEvent event) {
        try {
            // Cargar la vista de menu inicio de sesion
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("InicioSesion.fxml"));
            Parent menuInicioRoot = fxmlLoader.load();

             // Obtener el controlador de la ventana de inicio de sesión
            InicioSesionController inicioSesionController = fxmlLoader.getController();
            inicioSesionController.setParentController(this); // Pasar el controlador padre si es necesario

            // Crear una nueva ventana para el menu de iniicio de sesion
            Stage menuInicioStage = new Stage();
            menuInicioStage.setTitle("Menu de Inicio de Sesión");
            menuInicioStage.setScene(new Scene(menuInicioRoot));
            menuInicioStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            menuInicioStage.initOwner(btInicio.getScene().getWindow()); // Establecer la ventana principal como propietaria
            menuInicioStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de menu de inicio
        menuInicioStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            System.err.println("Error en abrir la ventana de Menu.fxml");
            e.printStackTrace();
        }
    }

    @FXML
    private void clickRegistrarse(MouseEvent event) {
    }

    @FXML
    private void actRegistrarse(ActionEvent event) {
        try {
            // Cargar la vista de registro
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Registro.fxml"));
            Parent registroRoot = fxmlLoader.load();

            // Obtener el controlador de la ventana de registro
            RegistroController registroController = fxmlLoader.getController();
            registroController.setParentController(this); // Pasar el controlador padre

            // Crear una nueva ventana para el registro
            Stage registroStage = new Stage();
            registroStage.setTitle("Registro de Usuario");
            registroStage.getIcons().add(new Image(getClass().getResourceAsStream("/imagenes/conecta4.png")));
            registroStage.setScene(new Scene(registroRoot));
            registroStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            registroStage.initOwner(btRegistrarse.getScene().getWindow()); // Establecer la ventana principal como propietaria
            registroStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de registro
        registroStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            System.err.println("Error al abrir la ventana de Registro.fxml");
            e.printStackTrace();
        }
    }

    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        Stage stage = (Stage) btSalir.getScene().getWindow();
        stage.close();
    }
        // Método para habilitar/deshabilitar botones
    public void desactivarbotones(boolean disabled) {
        btInicio.setDisable(disabled);
        btRegistrarse.setDisable(disabled);
    }
    
}
