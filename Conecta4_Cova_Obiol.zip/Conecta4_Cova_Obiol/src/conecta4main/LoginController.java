
package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class LoginController implements Initializable {

    @FXML
    private Button btInicio;
    @FXML
    private Button btRegistrarse;
    @FXML
    private Button btSalir;
    @FXML
    private TextField usuarioTextField;
    @FXML
    private PasswordField contraseñaTextField;
    private Player jugador1;
    private Player jugador2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inicialmente, deshabilitar el botón de inicio
        btInicio.setDisable(true);

        // Añadir listeners a los campos de usuario y contraseña
        usuarioTextField.textProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
        contraseñaTextField.textProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
    }

    // Método para verificar si los campos están vacíos
    private void verificarCampos() {
        boolean camposCompletos = !usuarioTextField.getText().trim().isEmpty() && !contraseñaTextField.getText().trim().isEmpty();
        btInicio.setDisable(!camposCompletos); // Habilitar/deshabilitar el botón de inicio
    }

    @FXML
    private void clickInicio(MouseEvent event) {
    }

    @FXML
    private void ActInicio(ActionEvent event) {
    String usuario = usuarioTextField.getText().trim();
    String contraseña = contraseñaTextField.getText().trim();

    try {
        Connect4 connect4 = Connect4.getInstance();
        Player player = connect4.loginPlayer(usuario, contraseña);

        if (player != null) {
            mostrarAlertas("Éxito", "Inicio de sesión exitoso.");
            this.jugador1 = player; // Asignar al jugador autenticado

            // Cargar la vista de inicio de sesión (menú principal)
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("InicioSesion.fxml"));
            Parent menuInicioRoot = fxmlLoader.load();

            // Obtener el controlador de la ventana de inicio de sesión
            InicioSesionController inicioSesionController = fxmlLoader.getController();
            inicioSesionController.setPlayers(jugador1, jugador2); // Pasar el jugador autenticado

            // Obtener la escena actual
            Stage currentStage = (Stage) btInicio.getScene().getWindow();
            Scene currentScene = currentStage.getScene();

            // Cambiar la raíz de la escena
            currentScene.setRoot(menuInicioRoot);

            // Opcional: actualizar el título y el icono
            currentStage.setTitle("Menú Principal");
            currentStage.getIcons().clear(); // Limpiar iconos anteriores si es necesario
            currentStage.getIcons().add(new Image(getClass().getResourceAsStream("/imagenes/conecta4.png")));

        } else {
            mostrarAlertas("Error", "Nombre de usuario o contraseña incorrectos.");
        }
    } catch (IOException e) {
        mostrarAlertas("Error", "Ocurrió un error al iniciar sesión.");
        e.printStackTrace();
    } catch (Exception e) {
        mostrarAlertas("Error", "Error inesperado: " + e.getMessage());
        e.printStackTrace();
    }
}


    @FXML
    private void clickRegistrarse(MouseEvent event) {
    }

    @FXML
    private void actRegistrarse(ActionEvent event) {
        try {
            // Cargar la vista de registro
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Registro.fxml"));
            Parent registroRoot = fxmlLoader.load();

            // Obtener el controlador de la ventana de registro
            RegistroController registroController = fxmlLoader.getController();
            registroController.setParentController(this); // Pasar el controlador padre

            // Crear una nueva ventana para el registro
            Stage registroStage = new Stage();
            registroStage.setTitle("Registro de Usuario");
            
            // Cargar el icono con verificación
            try (InputStream iconStream = getClass().getResourceAsStream("/imagenes/conecta4.png")) {
                if (iconStream != null) {
                    registroStage.getIcons().add(new Image(iconStream));
                } else {
                    mostrarAlertas("Error", "No se encontró la imagen del icono para el registro.");
                    System.err.println("No se pudo cargar '/imagenes/conecta4.png'");
                }
            } catch (IOException e) {
                mostrarAlertas("Error", "Error al cargar la imagen del icono: " + e.getMessage());
                e.printStackTrace();
            }

            registroStage.setScene(new Scene(registroRoot));
            registroStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            registroStage.initOwner(btRegistrarse.getScene().getWindow()); // Establecer la ventana principal como propietaria
            registroStage.show();

            // Deshabilitar los botones en la ventana principal
            desactivarbotones(true);

            // Volver a habilitar los botones al cerrar la ventana de registro
            registroStage.setOnHiding(e -> desactivarbotones(false));

        } catch (IOException e) {
            mostrarAlertas("Error", "Error al abrir la ventana de Registro.fxml");
            e.printStackTrace();
        }
    }



    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        Stage stage = (Stage) btSalir.getScene().getWindow();
        stage.close();
    }
    // Método para habilitar/deshabilitar botones
    public void desactivarbotones(boolean disabled) {
        btInicio.setDisable(disabled);
        btRegistrarse.setDisable(disabled);
    }

    private void mostrarAlertas(String title, String message) {
        Alert alert;
        switch (title.toLowerCase()) {
            case "error":
                alert = new Alert(Alert.AlertType.ERROR);
                break;
            case "éxito":
                alert = new Alert(Alert.AlertType.INFORMATION);
                break;
            default:
                alert = new Alert(Alert.AlertType.WARNING);
        }
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Método para establecer el jugador autenticado en el controlador padre
    public void setJugador1(Player jugador1) {
        this.jugador1 = jugador1;
    }
}
