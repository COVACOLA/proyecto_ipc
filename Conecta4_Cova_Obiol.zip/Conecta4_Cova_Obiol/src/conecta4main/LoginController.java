
package conecta4main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class LoginController implements Initializable {

    @FXML
    private Button btInicio;
    @FXML
    private Button btRegistrarse;
    @FXML
    private Button btSalir;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    

    @FXML
    private void clickInicio(MouseEvent event) {
    }

    @FXML
    private void ActInicio(ActionEvent event) {
    }

    @FXML
    private void clickRegistrarse(MouseEvent event) {
    }

    @FXML
    private void actRegistrarse(ActionEvent event) {
        try {
            // Cargar la vista de registro
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Registro.fxml"));
            Parent registroRoot = fxmlLoader.load();

            // Obtener el controlador de la ventana de registro
            RegistroController registroController = fxmlLoader.getController();
            registroController.setParentController(this); // Pasar el controlador padre

            // Crear una nueva ventana para el registro
            Stage registroStage = new Stage();
            registroStage.setTitle("Registro de Usuario");
            registroStage.setScene(new Scene(registroRoot));
            registroStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            registroStage.initOwner(btRegistrarse.getScene().getWindow()); // Establecer la ventana principal como propietaria
            registroStage.show();

            // Deshabilitar los botones en la ventana principal
            setButtonsDisabled(true);

            // Volver a habilitar los botones al cerrar la ventana de registro
        registroStage.setOnHiding(e -> setButtonsDisabled(false));

        } catch (IOException e) {
            System.err.println("Error al cargar el archivo Registro.fxml");
            e.printStackTrace();
        }
    }

    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        Stage stage = (Stage) btSalir.getScene().getWindow();
        stage.close();
    }
        // Método para habilitar/deshabilitar botones
    public void setButtonsDisabled(boolean disabled) {
        btInicio.setDisable(disabled);
        btRegistrarse.setDisable(disabled);
    }
    
}
