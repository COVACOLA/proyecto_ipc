/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class LoginJugador2Controller implements Initializable {
    @FXML
    private Button btInicio;
    @FXML
    private Button btRegistrarse;
    @FXML
    private Button btSalir;
    @FXML
    private TextField usuarioTextField;
    @FXML
    private PasswordField contraseñaTextField;
    private Player jugador2;
    @FXML
    private Button btRecordarContraseña;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inicialmente, deshabilitar el botón de inicio
        btInicio.setDisable(true);

        // Añadir listeners a los campos de usuario y contraseña
        usuarioTextField.textProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
        contraseñaTextField.textProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
    }

    // Método para verificar si los campos están vacíos
    private void verificarCampos() {
        boolean camposCompletos = !usuarioTextField.getText().trim().isEmpty() && !contraseñaTextField.getText().trim().isEmpty();
        btInicio.setDisable(!camposCompletos); // Habilitar/deshabilitar el botón de inicio
    }


    @FXML
    private void ActInicio(ActionEvent event) {
    String usuario = usuarioTextField.getText().trim();
    String contraseña = contraseñaTextField.getText().trim();

            try {
            Connect4 connect4 = Connect4.getInstance();
            Player player = connect4.loginPlayer(usuario, contraseña);

            if (player != null) {
                mostrarAlertas("Éxito", "Inicio de sesión exitoso.");
                jugador2 = player; // Asignar al jugador autenticado

                // Cerrar la ventana de LoginJugador2
                Stage stage = (Stage) btInicio.getScene().getWindow();
                stage.close();

            } else {
                mostrarAlertas("Error", "Nombre de usuario o contraseña incorrectos.");
            }
        } catch (Exception e) {
            mostrarAlertas("Error", "Ocurrió un error al iniciar sesión.");
            e.printStackTrace();
        }
    }


    @FXML
    private void actRegistrarse(ActionEvent event) {
        try {
                // Cargar la vista de registro
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("RegistroJugador2.fxml"));
                Parent registroRoot = fxmlLoader.load();

                // Obtener el controlador de la ventana de registro
                RegistroJugador2Controller registroJugador2Controller = fxmlLoader.getController();
                registroJugador2Controller.setParentController(this); // Pasar el controlador padre

                // Crear una nueva ventana para el registro
                Stage registroStage = new Stage();
                registroStage.setTitle("Registro de Usuario jugador 2");
                registroStage.setScene(new Scene(registroRoot));
                registroStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
                registroStage.initOwner(btRegistrarse.getScene().getWindow()); // Establecer la ventana principal como propietaria
                registroStage.show();            
                registroStage.setOnHiding(e -> desactivarbotones(false));
                desactivarbotones(true);
            } catch (IOException e) {
                mostrarAlertas("Error", "Error al abrir la ventana de Registro.fxml");
                e.printStackTrace();
            }
    }

    @FXML
    private void actSalir(ActionEvent event) {
        Stage stage = (Stage) btSalir.getScene().getWindow();
        stage.close();
    }
    // Método para habilitar/deshabilitar botones
    public void desactivarbotones(boolean disabled) {
        btInicio.setDisable(disabled);
        btRegistrarse.setDisable(disabled);
    }

    private void mostrarAlertas(String title, String message) {
        Alert alert;
        switch (title.toLowerCase()) {
            case "error":
                alert = new Alert(Alert.AlertType.ERROR);
                break;
            case "éxito":
                alert = new Alert(Alert.AlertType.INFORMATION);
                break;
            default:
                alert = new Alert(Alert.AlertType.WARNING);
        }
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public Player getJugador2() {
        return jugador2;
    }

    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void clickInicio(MouseEvent event) {
    }

    @FXML
    private void clickRegistrarse(MouseEvent event) {
    }

    @FXML
    private void actRecordarContraseña(ActionEvent event) {
            try {
            // Cargar la vista de registro
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("RecuperarContraseña.fxml"));
            Parent registroRoot = fxmlLoader.load();

            // Crear una nueva ventana para el registro
            Stage recuperarContraseñaStage = new Stage();
            recuperarContraseñaStage.setTitle("Recuperar Contraseña");
            recuperarContraseñaStage.setScene(new Scene(registroRoot));
            recuperarContraseñaStage.initModality(Modality.WINDOW_MODAL); // Bloquear la interacción con la ventana principal
            recuperarContraseñaStage.initOwner(btRegistrarse.getScene().getWindow()); // Establecer la ventana principal como propietaria
            recuperarContraseñaStage.show();            
            recuperarContraseñaStage.setOnHiding(e -> desactivarbotones(false));

            // Deshabilitar los botones de la ventana principal
            desactivarbotones(true);
        } catch (IOException e) {
            mostrarAlertas("Error", "Error al abrir la ventana de RecuperarContraseña.fxml");
            e.printStackTrace();
        }
    }
}
    
