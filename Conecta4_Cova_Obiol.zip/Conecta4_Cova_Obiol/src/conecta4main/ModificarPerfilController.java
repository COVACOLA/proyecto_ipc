package conecta4main;

import connect4.Player;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import java.io.File;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class ModificarPerfilController implements Initializable {

    @FXML
    private TextField usuarioField;
    @FXML
    private PasswordField contraField;
    @FXML
    private TextField correoField;
    @FXML
    private DatePicker fechaPicker;
    @FXML
    private Button botonGuardar;
    @FXML
    private Button cancelarBoton;
    @FXML
    private Button cambiaravatarBoton;
    @FXML
    private ImageView avatarImageView;

    private Player jugadorActual; // Referencia al jugador que se edita

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDatosJugador(); // Cargar datos al inicializar
    }

    public void setJugadorActual(Player jugador) {
        this.jugadorActual = jugador;
        cargarDatosJugador();
    }

    private void cargarDatosJugador() {
        if (jugadorActual != null) {
            usuarioField.setText(jugadorActual.getNickName());
            usuarioField.setDisable(true); // No editable
            correoField.setText(jugadorActual.getEmail());
            fechaPicker.setValue(jugadorActual.getBirthdate());
            avatarImageView.setImage(jugadorActual.getAvatar());
        }
    }

    @FXML
    private void cambiarAvatar(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );
        File archivoSeleccionado = fileChooser.showOpenDialog(null);
        if (archivoSeleccionado != null) {
            Image avatar = new Image(archivoSeleccionado.toURI().toString());
            avatarImageView.setImage(avatar);
        }
    }

    @FXML
    private void guardarCambios(ActionEvent event) {
        String nuevaContra = contraField.getText();
        String nuevoCorreo = correoField.getText();
        LocalDate nuevaFecha = fechaPicker.getValue();
        Image nuevoAvatar = avatarImageView.getImage();

        // Validar los datos ingresados
        if (!validarContrasena(nuevaContra)) {
            mostrarAlerta("Error", "La contraseña debe tener entre 8 y 20 caracteres, incluir mayúsculas, minúsculas, dígitos y caracteres especiales.");
            return;
        }

        if (!validarCorreo(nuevoCorreo)) {
            mostrarAlerta("Error", "El correo electrónico no tiene un formato válido.");
            return;
        }

        if (!validarFechaNacimiento(nuevaFecha)) {
            mostrarAlerta("Error", "Debes tener al menos 12 años.");
            return;
        }

        // Actualizar los datos del jugador
        jugadorActual.setPassword(nuevaContra);
        jugadorActual.setEmail(nuevoCorreo);
        jugadorActual.setBirthdate(nuevaFecha);
        jugadorActual.setAvatar(nuevoAvatar);

        mostrarAlerta("Éxito", "Los cambios se han guardado correctamente.");
    }

    @FXML
    private void cancelar(ActionEvent event) {
        cancelarBoton.getScene().getWindow().hide(); // Cerrar la ventana
    }

    private boolean validarContrasena(String contrasena) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%!&*()+=-]).{8,20}$";
        return Pattern.matches(regex, contrasena);
    }

    private boolean validarCorreo(String correo) {
        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return Pattern.matches(regex, correo);
    }

    private boolean validarFechaNacimiento(LocalDate fechaNacimiento) {
        if (fechaNacimiento == null) return false;
        return fechaNacimiento.isBefore(LocalDate.now().minusYears(12));
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if ("Error".equalsIgnoreCase(titulo)) {
            alert.setAlertType(Alert.AlertType.ERROR);
        }
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
