/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class RankingController implements Initializable {

    @FXML
    private TableView<Player> tablaPuntos;
    @FXML
    private TableColumn<Player, String> usuario;
    @FXML
    private TableColumn<Player, Integer> puntos;
    @FXML
    private TextField buscador;

    private ObservableList<Player> datosRanking;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        configurarTabla();
        cargarRanking();
        configurarBusqueda();
    }

    private void configurarTabla() {
        usuario.setCellValueFactory(new PropertyValueFactory<>("usuario"));
        puntos.setCellValueFactory(new PropertyValueFactory<>("puntuacion"));

        datosRanking = FXCollections.observableArrayList();
        tablaPuntos.setItems(datosRanking);
    }

    private void cargarRanking() {
        try {
            Connect4 connect4 = Connect4.getInstance();
            List<Player> players = connect4.getRanking();
            datosRanking.setAll(players);
        } catch (Exception e) {
            System.err.println("Error al cargar el ranking: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void configurarBusqueda() {
        buscador.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                tablaPuntos.setItems(datosRanking);
            } else {
                String filtro = newValue.toLowerCase();
                ObservableList<Player> resultadosFiltrados = FXCollections.observableArrayList();
                for (Player player : datosRanking) {
                    if (player.getNickName().toLowerCase().contains(filtro)) {
                        resultadosFiltrados.add(player);
                    }
                }
                tablaPuntos.setItems(resultadosFiltrados);
            }
        });
    }
}


