/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class RecuperarContraseñaController implements Initializable {

    @FXML
    private TextField usuarioTextfield;
    @FXML
    private TextField correroTextfield;
    @FXML
    private Button confimarDatos;
    @FXML
    private Button btSalir;

    private String codigoGenerado;
    private Player jugador; 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void actUsuario(ActionEvent event) {
    }

    @FXML
    private void actCorreo(ActionEvent event) {
    }

    @FXML
    private void clickInicio(MouseEvent event) {
    }

    @FXML
    private void ActConfimarDatos(ActionEvent event) {
        String usuario = usuarioTextfield.getText().trim();
        String correo = correroTextfield.getText().trim();

        if (usuario.isEmpty() || correo.isEmpty()) {
            mostrarAlerta("Error", "Por favor, completa ambos campos.");
            return;
        }

        try {
            Connect4 connect4 = Connect4.getInstance();
            jugador = connect4.getPlayer(usuario);

            if (jugador == null) {
                mostrarAlerta("Error", "El usuario no existe.");
            } else if (!jugador.getEmail().equalsIgnoreCase(correo)) {
                mostrarAlerta("Error", "El correo no coincide con el registrado.");
            } else {
                // Generar código de seguridad
                generarCodigoSeguridad();
                
                // Mostrar el código en una alerta simulando el envío del correo
                mostrarAlerta("Código de Seguridad", 
                              "Se ha enviado un código de seguridad a tu correo.\n\n" + 
                              "Simulación: Tu código es " + codigoGenerado);

                // Verificar el código ingresado
                verificarCodigo();
            }
        } catch (Exception e) {
            mostrarAlerta("Error", "Hubo un problema al procesar los datos.");
            e.printStackTrace();
        }
    }

    @FXML
    private void clickSalir(MouseEvent event) {
    }

    @FXML
    private void actSalir(ActionEvent event) {
        btSalir.getScene().getWindow().hide();
    }
    
        private void generarCodigoSeguridad() {
        Random random = new Random();
        codigoGenerado = String.format("%06d", random.nextInt(1000000)); // Genera un código de 6 dígitos
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if ("Error".equalsIgnoreCase(titulo)) {
            alert.setAlertType(Alert.AlertType.ERROR);
        }
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private String mostrarDialogo(String titulo, String mensaje) {
        // Crear un cuadro de diálogo para solicitar el código
        TextField input = new TextField();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);

        alert.getDialogPane().setContent(input); // Agregar el campo de texto al cuadro de diálogo
        alert.showAndWait();

        return input.getText(); // Devolver el texto ingresado
    }
    
    private void verificarCodigo() {
        // Mostrar un cuadro de diálogo para ingresar el código
        String codigoIngresado = mostrarDialogo("Introduce el Código de Seguridad", 
                                                "Ingresa el código que has recibido:");

        if (codigoIngresado == null || codigoIngresado.isEmpty()) {
            mostrarAlerta("Error", "No se ingresó ningún código.");
            return;
        }

        if (codigoGenerado.equals(codigoIngresado)) {
            mostrarAlerta("Éxito", "Tu contraseña es: " + jugador.getPassword());
        } else {
            mostrarAlerta("Error", "El código de seguridad no coincide. Por favor, inténtalo de nuevo.");
        }
    }


}
