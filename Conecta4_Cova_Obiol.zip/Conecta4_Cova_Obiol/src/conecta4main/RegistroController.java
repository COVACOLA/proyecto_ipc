/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package conecta4main;

import connect4.Connect4;
import connect4.Player;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.Period;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jcova
 */
public class RegistroController implements Initializable {

    @FXML
    private TextField correoTextfield;
    @FXML
    private TextField usuarioTextfield;
    @FXML
    private Button registrarse;
    @FXML
    private Button cancelar;
    @FXML
    private DatePicker datePicker;
    @FXML
    private PasswordField passwordTexfield;
    @FXML
    private ImageView imagenView;
    @FXML
    private Button seleccionarImagen;
    
    private File archivoImagen;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Desactivar el botón al inicio
        registrarse.setDisable(true);

        // Validación en tiempo real
        ChangeListener<String> listener = (observable, oldValue, newValue) -> verificarCampos();
        usuarioTextfield.textProperty().addListener(listener);
        correoTextfield.textProperty().addListener(listener);
        passwordTexfield.textProperty().addListener(listener);
        datePicker.valueProperty().addListener((observable, oldValue, newValue) -> verificarCampos());
    }
        

    @FXML
    private void botonRegistrarse(ActionEvent event) {
        String usuario = usuarioTextfield.getText().trim();
        String correo = correoTextfield.getText().trim();
        String password = passwordTexfield.getText().trim();
        LocalDate fechaNacimiento = datePicker.getValue();
        String imagenPath = (archivoImagen != null) ? archivoImagen.getAbsolutePath() : "default.png";

        resetearEstilos();

        if (!camposValidos(usuario, correo, password, fechaNacimiento)) {
            return;
        }

        // Validar si el usuario tiene más de 12 años
        if (Period.between(fechaNacimiento, LocalDate.now()).getYears() < 12) {
            mostrarAlertas("Error", "Debes tener más de 12 años para registrarte.");
            datePicker.getStyleClass().add("error");
            return;
        }

        try {
            Connect4 connect4 = Connect4.getInstance();
            if (connect4.existsNickName(usuario)) {
                mostrarAlertas("Error", "El nombre de usuario ya está en uso. Por favor, elige otro.");
                usuarioTextfield.getStyleClass().add("error");
                return;
            }

            // Si hay una imagen seleccionada, actualizar el avatar
            String avatarPath = archivoImagen != null ? archivoImagen.toURI().toString() : getClass().getResource("/imagenes/default.png").toString();
            connect4.registerPlayer(usuario, correo, password, fechaNacimiento, 0);


            mostrarAlertas("Éxito", "Usuario registrado correctamente.");

        // Cambiar a la escena de login
            Stage stage = (Stage) registrarse.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            mostrarAlertas("Error", "Ocurrió un error al registrar al usuario.");
            e.printStackTrace();
        }
    }
/*            // Cambiar a la escena de login
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml")); // Asegúrate de que el FXML es el correcto
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Stage stage = (Stage) registrarse.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            mostrarAlertas("Error", "Ocurrió un error al registrar al usuario. Inténtalo de nuevo.");
            e.printStackTrace();
        } catch (Exception e) {
            mostrarAlertas("Error", "Error inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }
*/

    @FXML
    private void botonCancelar(ActionEvent event) {
        cancelar.getScene().getWindow().hide();

    }

   
    
    @FXML
    private void actionSeleccionarImagen(ActionEvent event) {
        
    }


    @FXML
    private void botonSeleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar imagen");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg"));

        File selectedFile = fileChooser.showOpenDialog(seleccionarImagen.getScene().getWindow());
        if (selectedFile != null) {
            archivoImagen = selectedFile;
            imagenView.setImage(new Image(selectedFile.toURI().toString()));
        } else {
            mostrarAlertas("Advertencia", "No se seleccionó ninguna imagen.");
        }
    }

    private boolean camposValidos(String usuario, String correo, String contraseña, LocalDate fechaNacimiento) {
        resetearEstilos();
        StringBuilder errores = new StringBuilder();
        boolean valido = true;

        if (usuario.isEmpty() || !usuarioValido(usuario)) {
            usuarioTextfield.getStyleClass().add("error");
            errores.append("- El nombre de usuario debe tener entre 6 y 15 caracteres, sin espacios y puede incluir guiones o subguiones.\n");
            valido = false;
        }
        if (correo.isEmpty() || !emailValido(correo)) {
            correoTextfield.getStyleClass().add("error");
            errores.append("- El correo electrónico no es válido.\n");
            valido = false;
        }
        if (contraseña.isEmpty() || !contraseñaValida(contraseña)) {
            passwordTexfield.getStyleClass().add("error");
            errores.append("- La contraseña debe tener entre 8 y 20 caracteres, con mayúsculas, minúsculas, números y caracteres especiales (@#$%&*()-+=).\n");
            valido = false;
        }
        if (fechaNacimiento == null) {
            datePicker.getStyleClass().add("error");
            errores.append("- Debes seleccionar tu fecha de nacimiento.\n");
            valido = false;
        }

        if (!valido) {
            mostrarAlertas("Error", errores.toString());
        }
        return valido;
    }

    private boolean usuarioValido(String usuario) {
        return usuario.matches("[a-zA-Z0-9_-]{6,15}");
    }

    private boolean emailValido(String email) {
        return email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
    }

    private boolean contraseñaValida(String contraseña) {
        return contraseña.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%&*()\\-+=]).{8,20}$");
    }

    private void mostrarAlertas(String title, String message) {
        Alert alert;
        switch (title.toLowerCase()) {
            case "error":
                alert = new Alert(Alert.AlertType.ERROR);
                break;
            case "éxito":
                alert = new Alert(Alert.AlertType.INFORMATION);
                break;
            default:
                alert = new Alert(Alert.AlertType.WARNING);
        }
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private void resetearEstilos() {
        usuarioTextfield.getStyleClass().removeAll("error");
        correoTextfield.getStyleClass().removeAll("error");
        passwordTexfield.getStyleClass().removeAll("error");
        datePicker.getStyleClass().removeAll("error");
    }

    private void verificarCampos() {
        boolean camposCompletos = !usuarioTextfield.getText().trim().isEmpty()
                && !correoTextfield.getText().trim().isEmpty()
                && !passwordTexfield.getText().trim().isEmpty()
                && datePicker.getValue() != null;

        registrarse.setDisable(!camposCompletos); // Habilitar/deshabilitar el botón
    }

    private LoginController parentController;

    // Método para establecer el controlador padre
    public void setParentController(LoginController parentController) {
        this.parentController = parentController;
    }

} 
